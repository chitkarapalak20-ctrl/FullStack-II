import StudentCard from "./StudentCard"



function App() {
  const studentdata = [{
    name: "John Doe",
    age: 20,
    grade: "A",
    course: "Computer Science"
  }, {
    name: "Jane Smith",
    age: 22,
    grade: "B",
    course: "Mathematics"

    }, {
    name: "Bob Johnson",
    age: 21,
    grade: "C",
    course: "Physics"
  }]
  return (
    <>
   <StudentCard/>
    </>
    
  )
}

export default App
